% EM with Potts penalty
% Huazhang Li
% Version 02042017


function [A, sgm2, C, Q, R, Mu, V, m0, dif, jtlhd, xTT] = EM_Potts_C(y,a,c,q,r,mu,v,tol,miter,lambda)

% EM algorithm for parameter estimation (with Potts penalty)
%
% input:
% y: observed data, dimension p by T
% a,q,r,pi,v: inital parameter values
% miter: max number of iterations
% tol: tolerance for difference between two successive iterations
%
% output:
% A,Q,R,Pi,V: final parameter estimations

if nargin < 9
    tol=1e-6;
end

[~,d]=size(q);
[~,T]=size(y);

A=a; C=c; Q=q; R=r; Mu=mu; V=v;

iter=1; dif=1;

Pt=zeros(d,d,T+1);
Ptt_1=zeros(d,d,T);

% Start from d clusters
m0 = 1:d;

jtlhd = [];

while (iter<miter)&&(dif>tol)
    disp(iter);
    
    %% E step:
    
    [~,~,~,~,Fvy, Fy, Sx,Sv,Scov] = K_F_S(A, C, Q, R, Mu, V, y);
    
    for t=1:(T+1)
        Pt(:,:,t)=Sv(:,:,t)+Sx(:,t)*Sx(:,t)';
    end
    
    for t=1:(T)
        Ptt_1(:,:,t)=Scov(:,:,t)+Sx(:,t+1)*Sx(:,t)';
    end

    xTT = Sx(:, T+1);
    
    
    %% M step:
    
    % Estimate A
    [m_best, A_potts] = A_Modular_C(T, m0, Pt, Ptt_1, lambda);
    
    m0 = m_best;
    Anew = A_potts;
    
    
    
    % Estimate sigma^2
    sgm2 = 1;
    
    
    % Estimate C
    % Diagonal C
    
    C_dia = ones(1,d);
    C_tmp = diag(y * (Sx(:,2:(T+1)))');
    
    for i = 1:d
        C_dia(i) = (1/sum(Pt(i,i,2:(T+1)), 3)) *  C_tmp(i);
    end
    
    Cnew = diag(C_dia);      
    
    
    % Estimate R, assume R diagonal 
    Rnew = (y*y' - y*(Sx(:,2:(T+1)))'*Cnew' - Cnew*Sx(:,2:(T+1))*y' + Cnew*sum(Pt(:,:,2:(T+1)),3)*Cnew')/T;
    
    Rnew = diag(diag(Rnew));


    % Estimate Mu
    Munew=Sx(:,1);
    
    % Estimate Q
    % If we want Q to be Identity
    Qnew=sgm2 * eye(d);
    
    % Estimate V0
    Vnew = V;
    
    
    %% Calculate joint log likelihood
    
    jtlhd_now1 = 0;
    
    for i = 1:T
        jtlhd_now1 = jtlhd_now1 + log(det(Fvy(:,:,i)));
    end
    
    jtlhd_now2 = 0;
    
    for i = 1:T
        jtlhd_now2 = jtlhd_now2 + (y(:, i) - Fy(:,i))'*inv(Fvy(:,:,i))*(y(:, i) - Fy(:,i));
    end    
    
    jtlhd_now = - 0.5 * jtlhd_now1 - 0.5 * jtlhd_now2 - lambda * nnz(A);
    jtlhd = [jtlhd jtlhd_now];  

    
    %% Updates
    dif=norm(Rnew-R)+norm(Anew-A)+norm(Cnew-C)+norm(Qnew-Q)+norm(Munew-Mu)+norm(Vnew-V);
    iter=iter+1;    
    R=Rnew;A=Anew;C=Cnew;Q=Qnew;Mu=Munew;V=Vnew;
    
end
end
