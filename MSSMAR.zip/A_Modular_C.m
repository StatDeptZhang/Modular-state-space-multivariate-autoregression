% Estimate A matrix for system with modularity structure
% Huazhang Li
% Version 11122016 


function [m_best, A_potts] = A_Modular_C(T, m0, Pt, Ptt_1, lambda)

[d,~,~]=size(Pt);

alpha0 = ones(d*d, 1);

m_best = m0;

ZTX_0 = sum(Ptt_1,3);
ZTX0 = reshape(ZTX_0, [d*d ,1]);

ZTZ_0 = sum(Pt(:,:,1:T),3);
ZTZ0 = kron(ZTZ_0, eye(d));

% Calculate the initial penalized residual according to m0

        alpha0_ind = alpha0;
        m_tmp = m0;
        ZTZ_tmp = ZTZ0;
        ZTX_tmp = ZTX0;
        
        % Update alpha structure based on module label
        
        for k = 1:d
           for w = 1:d
               if m_tmp(k) ~= m_tmp(w)
                   alpha0_ind((k-1)*d + w) = 0;
               end
           end            
        end
        
        
        % Partitioned parameter estimation
        
        m_tmp2 = m_tmp;
                        
        for k = 1:d
           
            if m_tmp2(k) ~= 0
                
                c = [];
                
                for w = k:d
                    
                    if m_tmp2(w) == m_tmp2(k)
                        
                        c = [c w];
                        
                    end
                     
                end
                
                
                l = length(c);
                
                ps = [];
                
                for p = 1:l
                    
                    for q = 1 : l
                        
                        ps = [ps ((c(p) - 1)*d + c(q))];
                        
                    end
                    
                end
                
                
                ZTZ_tmp1 = ZTZ_tmp(ps, ps);
                ZTX_tmp1 = ZTX_tmp(ps);
                
                alpha_sec = ZTZ_tmp1 \ ZTX_tmp1;
                
                alpha0_ind(ps) = alpha_sec;
                
                m_tmp2(c) = 0;              
                                   
            end
                        
        end
        
        alpha0 = alpha0_ind;

        alpha_best = alpha0;

        std = (-1)*alpha0'*ZTX0 + 0.5 * alpha0' * ZTZ0 * alpha0 + lambda * nnz(alpha0);
% 


% Finished calculate the initial penalized residual

% Identify the optimal feasible label changes

uniquem0 = unique(m0);

notinm0 = setdiff(1:d, uniquem0);

feaslabel = [uniquem0, min(notinm0)]; 

J = length(feaslabel);

% Finished identify the optimal feasible label changes

for i = 1:d
    for j = 1:J
        
        alpha_tmp = ones(d*d, 1);
        m_tmp = m0;
        
        if m_tmp(i) == feaslabel(j)
            continue
        end
        
        m_tmp(i) = feaslabel(j);
        ZTZ_tmp = ZTZ0;
        ZTX_tmp = ZTX0;
         
                  
        % Update alpha structure based on module label: 
        % set A_ij of different clusters to 0
        for k = 1:d
           for w = 1:d
               if m_tmp(k) ~= m_tmp(w)
                   alpha_tmp((k-1)*d + w) = 0;
               end
           end            
        end
        
        % Partitioned parameter estimation
        
        m_tmp2 = m_tmp;
        
        
        
        for k = 1:d
           
            if m_tmp2(k) ~= 0
                
                c = [];
                
                for w = k:d
                    
                    if m_tmp2(w) == m_tmp2(k)
                        
                        c = [c w];
                        
                    end
                     
                end
                
                
                l = length(c);
                
                ps = [];
                
                for p = 1 : l
                    
                    for q = 1 : l
                        
                        ps = [ps ((c(p) - 1)*d + c(q))];
                        
                    end
                    
                end
                                
                ZTZ_tmp1 = ZTZ_tmp(ps, ps);
                ZTX_tmp1 = ZTX_tmp(ps);
                
                alpha_sec = ZTZ_tmp1 \ ZTX_tmp1;
                
                alpha_tmp(ps) = alpha_sec;
                
                m_tmp2(c) = 0;              
                                    
            end
                        
        end
                
        % Make comparison

        std_tmp = (-1)*alpha_tmp'*ZTX0 + 0.5 * alpha_tmp' * ZTZ0 * alpha_tmp + lambda * nnz(alpha_tmp);
        
        if std_tmp < std
            
            alpha_best = alpha_tmp;
            m_best = m_tmp;
            std = std_tmp;
            
        end
        
    end    
end

A_potts = reshape(alpha_best, [d,d]);

end
