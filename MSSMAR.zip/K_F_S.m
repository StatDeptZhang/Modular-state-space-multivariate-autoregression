function [Fv1,Fv2,Fx1,Fx2,Fvy, Fy, Sx,Sv,Scov] = K_F_S(A, C, Q, R, x0, v0, y)
% General Kalman filter and smoother
% Huazhang Li
% Version Dropbox 12062018
%
% The model:
% x(t+1) = A x(t) + w(t), x(t) is d by 1
% y(t) = C x(t) + v(t), y(t) is d by 1
% w(t) ~ iid N(0,Q), Q Identity
% v(t) ~ iid N(0,R), R diagonal
% t = 1,2,...,T
% x(0) ~ N(x0,I)
%
% Input:
% A,C,Q,R,x0,v0 are as above
% y is observation matrix, dimension d by T
%
% Output:
% Fx1,Fx2,Sx are d by T matrices
% Fv1,Fv2,Sv,Scov are d by d by T arrays

% Fv1, (:,:,t)  is Var(x(t)|y(1:t))
% Fv2, (:,:,t)  is Var(x(t)|y(1:(t-1)))
% Fx1, column t is E(x(t)|y(1:t))
% Fx2, column t is E(x(t+1)|y(1:t))
% Sx,  column t is E(x(t)|y(1:T))
% Sv,  (:,:,t)  is Var(x(t)|y(1:T))
% Scov,(:,:,t)  is Cov(x(t),x(t+1)|y(1:T))

% Initilizations
[~,T]=size(y);
[d,~]=size(A);

Fv1=zeros(d,d,T);
Fx1=zeros(d,T);

Fv2=zeros(d,d,T);
Fx2=zeros(d,T);

Fvy=zeros(d,d,T);
Fy=zeros(d,T);

Sx=zeros(d,T+1);
Sv=zeros(d,d,T+1);
Scov=zeros(d,d,T);




% Filter
for t = 1:T
    if t == 1

        Fx2(:,t) = A*x0;
        Fv2(:,:,t) = A*v0*A' + Q;
        Fy(:,t) = C*Fx2(:,t);
        Fvy(:,:,t) = C*Fv2(:,:,t)*C' + R;
        Kt = Fv2(:,:,t)*C'/Fvy(:,:,t);
        Fx1(:,t) = Fx2(:,t) + Kt*(y(:,t) - Fy(:,t));
        Fv1(:,:,t) = Fv2(:,:,t) - Kt*C*Fv2(:,:,t);
                      
    else
    
        Fx2(:,t) = A*Fx1(:,t-1);
        Fv2(:,:,t) = A*Fv1(:,:,t-1)*A' + Q;
        Fy(:,t) = C*Fx2(:,t);
        Fvy(:,:,t) = C*Fv2(:,:,t)*C' + R;
        Kt = Fv2(:,:,t)*C'/Fvy(:,:,t);
        Fx1(:,t) = Fx2(:,t) + Kt*(y(:,t) - Fy(:,t));
        Fv1(:,:,t) = Fv2(:,:,t) - Kt*C*Fv2(:,:,t);
                
    end
end




% Smoother
for i=1:(T+1)
    t=T-i+2;
    
    if t == (T+1)
        
        Sv(:,:,t)=Fv1(:,:,T);
        Sx(:,t)=Fx1(:,T);
        
    elseif t == 1
        
        J=v0*A'/(Fv2(:,:,t));
        Sx(:,t)=x0+J*(Sx(:,t+1)-A*x0);
        Sv(:,:,t)=v0+J*(Sv(:,:,t+1)-Fv2(:,:,t))*J';
        Scov(:,:,t)=Sv(:,:,t+1)*J';          
                
    else
        
        J=Fv1(:,:,t-1)*A'/(Fv2(:,:,t));
        Sx(:,t)=Fx1(:,t-1)+J*(Sx(:,t+1)-A*Fx1(:,t-1));
        Sv(:,:,t)=Fv1(:,:,t-1)+J*(Sv(:,:,t+1)-Fv2(:,:,t))*J';
        Scov(:,:,t)=Sv(:,:,t+1)*J';        
                
    end
end

end