% Estimate Initial A matrix for KFS algorithm using VAR(1)
% Huazhang Li
% Version 11062016



function [A_0] = IniVAR(Y)

% [d,~]=size(Y);
% 
% Yvar = Y';
% 
% md = vgxset('n',d,'nAR',1,'Constant',true);
% 
% [EstSpec] = vgxvarx(md, Yvar);
% 
% A_0 = EstSpec.AR{1};
[VAR, ~] = VARmodel(Y, 1, 0);

A_0 = VAR.Ft;

end


