function [] = ContPanel(array_index)
% Control Panel for MSSMAR
% Matlab version is Matlab R2018b

%% Set the penalty parameter
% lambda_list is the range of penalty parameters. 
% The example is for the first screening step.
lambda_list = 2.^[1:10]; 
lambda = lambda_list(array_index);


%% Load data
% Simulation_1_800.mat, Simulation_1_400.mat and Simulation_1_200.mat
% are the simulations in Section 4.1;
% Simulation_2.mat is the simulation in Section 4.2;
% Simulation_1_Atrue.mat and Simulation_2_Atrue.mat are the ture adjacent
% matrices of the networks.
filename = 'Simulation_1_800.mat';
% filename = 'Simulation_2.mat';
y = importdata(filename);
filename2 = sprintf('result_%d',array_index);


addContainingDirAndSubDir();

%% Initialization

Y = y';
Y = datastd(Y);
[T,d]=size(Y);
A = IniVAR(Y);
Y = transpose(Y);
C = eye(d);

Q = eye(d);

R = eye(d);

v0 = eye(d);

x0 = Y(:,1);

y = Y;


A_0 = A;
C_0 = C;
Q_0 = Q;
R_0 = R;
mu = x0;
v = v0;
tol=1e-6;

% Set the maximum number of iterations
miter= 2*d + 1;


%% Run EM algorithm

tic

[A_1, sgm2, C_1, Q_1, R_1, mu_1, V_1, m0, Dif, ~, ~] = EM_Potts_C(y,A_0,C_0,Q_0,R_0,mu,v,tol,miter,lambda);

toc

% Calculate the AIC
[~,~,~,~,Fvy, Fy, Sx,Sv,Scov] = K_F_S(A_1, C_1, Q_1, R_1, mu_1, V_1, y);
    
jtlhd_now1 = 0;
    
for i = 1:T
    jtlhd_now1 = jtlhd_now1 + log(det(Fvy(:,:,i)));
end
    
jtlhd_now2 = 0;
    
for i = 1:T
    jtlhd_now2 = jtlhd_now2 + (y(:, i) - Fy(:,i))'*inv(Fvy(:,:,i))*(y(:, i) - Fy(:,i));
end    
    
jtlhd_now = - 0.5 * jtlhd_now1 - 0.5 * jtlhd_now2;
    
AIC = (nnz(A_1)-d) - 2*(jtlhd_now);


%% Save the results
save(filename2);

end